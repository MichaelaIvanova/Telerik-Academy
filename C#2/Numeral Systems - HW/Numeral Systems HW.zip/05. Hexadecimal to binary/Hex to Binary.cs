﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05.Hexadecimal_to_binary
{
    class Program
    {
// Влючено е в  03 и 0.4 работят и за отрицателни числа и са вързани и за десетични.Превърщам хекса в бинарно за да видя дали е поситивно или негативно
        static void Main(string[] args)
        {
        }
    }
}
