﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _06.Binary_to_hexadecimal
{
    class BintoHex
    {
 // Влючено е в  03 и 0.4 работят и за отрицателни числа и са вързани и за десетични.Превърщам хекса в бинарно за да видя дали е позитивно или негативно
        static void Main(string[] args)
        {
        }
    }
}
