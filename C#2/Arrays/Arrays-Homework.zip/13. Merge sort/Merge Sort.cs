﻿using System;

    class Program
    {
        //Write a program that sorts an array of integers using the Merge sort algorithm.
        static void Main()
        {

        }
    }

