﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04.Fill_matrix_D
{
    class FillD
    {
        static void Main(string[] args)
        {

        }
    }
}
