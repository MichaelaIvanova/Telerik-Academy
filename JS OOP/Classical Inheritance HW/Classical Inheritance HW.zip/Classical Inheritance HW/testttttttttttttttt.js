/**
 * Created by b50 on 21.6.2015 �..
 */
    var text = 'abasfyf';
var onlyLetters = /^[a-zA-Z]*$/.test(text);
console.log(onlyLetters);

var q = 123;
console.log(!isNaN(q));
