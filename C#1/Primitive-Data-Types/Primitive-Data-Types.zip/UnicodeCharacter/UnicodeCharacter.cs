﻿using System;

    class Program
    {
        static void Main()
        {
            decimal c = '\u002A';
            Console.WriteLine((char)c);
          
        }
    }

