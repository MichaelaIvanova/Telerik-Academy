﻿using System;

    class HexVariable
    {
        static void Main()
        {
            int hexVariable = 0xFE;
            Console.WriteLine((int)hexVariable);
        }
    }

