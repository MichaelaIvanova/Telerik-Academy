﻿using System;

    class IsoscelesTriangle
    {
        static void Main()
        {

            Console.OutputEncoding = System.Text.Encoding.Unicode;
            char c = '\u00a9';
            Console.SetCursorPosition(8, 1);
            Console.WriteLine(c);
            Console.WriteLine();
            Console.SetCursorPosition(6, 2);
            Console.WriteLine(c);
            Console.SetCursorPosition(10, 2);
            Console.WriteLine(c);
            Console.WriteLine();
            Console.SetCursorPosition(4, 3);
            Console.WriteLine(c);
            Console.SetCursorPosition(12, 3);
            Console.WriteLine(c);
            Console.WriteLine();
            Console.SetCursorPosition(2, 4);
            Console.WriteLine(c);
            Console.SetCursorPosition(6, 4);
            Console.WriteLine(c);
            Console.SetCursorPosition(10, 4);
            Console.WriteLine(c);
            Console.SetCursorPosition(14, 4);
            Console.WriteLine(c);

        }
    }

