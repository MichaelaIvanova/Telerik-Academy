﻿using System;

    class DeclareVariables
    {
        static void Main()
        {
            ushort number1 = 52130;
            sbyte number2 = -115;
            uint number3 = 4825932;
            byte number4 = 97;
            short number5 = -1000;
            Console.WriteLine("{0} is Ushort\n {1} is Sbyte\n {2} is Uint\n {3} is Byte\n {4} is Short\n", number1, number2, number3, number4, number5);
        }
    }

