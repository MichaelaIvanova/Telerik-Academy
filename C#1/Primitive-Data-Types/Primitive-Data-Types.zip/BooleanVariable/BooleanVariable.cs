﻿using System;

    class BooleanVariable
    {
        static void Main()
        {
            bool isFemale = true;
            Console.WriteLine("Am I a female?: {0}", isFemale);
        }
    }

