﻿using System;

    class Sqr12345
    {
        static void Main()
        {
            Console.WriteLine(Math.Sqrt(12345));
        }
    }

