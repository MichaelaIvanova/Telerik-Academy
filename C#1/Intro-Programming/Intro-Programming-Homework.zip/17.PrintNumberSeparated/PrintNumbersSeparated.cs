﻿using System;

    class PrintNumbersSeparated
    {
        static void Main()
        {
            {
                Console.BufferHeight = 1001;
                for (int i = 1; i < 1001; i++)
                {
                    Console.WriteLine(i);
                }
            }
        }
    }
