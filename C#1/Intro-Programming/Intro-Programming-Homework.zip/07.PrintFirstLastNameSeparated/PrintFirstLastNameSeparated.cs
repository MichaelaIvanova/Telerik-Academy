﻿using System;

    class PrintFirstLastNameSeparated
    {
        static void Main()
        {
            Console.WriteLine("Michaela\nIvanova");
        }
    }

