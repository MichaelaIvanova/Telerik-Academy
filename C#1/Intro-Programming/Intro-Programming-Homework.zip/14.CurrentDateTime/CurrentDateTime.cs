﻿using System;

    class CurrentDateTime
    {
        static void Main()
        {
            DateTime now = DateTime.Now;
            Console.WriteLine(now);
        }
    }

